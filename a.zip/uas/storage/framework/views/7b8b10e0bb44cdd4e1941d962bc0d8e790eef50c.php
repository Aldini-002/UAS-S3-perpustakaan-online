<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="rew justify-content-center">
            <div class="col-6">
                <div class="row">
                    <div class="col-12">
                        <h1>Daftar permintaan</h1>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama peminjam</th>
                                    <th scope="col">Kode buku</th>
                                    <th scope="col">Tanggal pinjam</th>
                                    <th scope="col">Batas pinjam</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pinjams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($no++); ?></th>
                                        <td><?php echo e($pinjam->user->name); ?></td>
                                        <td><?php echo e($pinjam->buku->kode); ?></td>
                                        <td><?php echo e($pinjam->tanggal_pinjam); ?></td>
                                        <td><?php echo e($pinjam->batas_pinjam); ?></td>
                                        <td><a href="/pinjam/request/tolak/<?php echo e($pinjam->id); ?>">Tolak</a> || <a
                                                href="/pinjam/request/terima/<?php echo e($pinjam->id); ?>">Terima</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- add Modal -->
    <div class="modal fade" id="add" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Add pinjam</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/pinjam/add" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Kode</label>
                            <input type="text" class="form-control" name="kode" value="<?php echo e(old('kode')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Baris</label>
                            <input type="number" class="form-control" name="baris" value="<?php echo e(old('baris')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Kolom</label>
                            <input type="number" class="form-control" name="kolom" value="<?php echo e(old('kolom')); ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- update Modal -->
    <?php $__currentLoopData = $pinjams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="update<?php echo e($pinjam->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
            tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Update pinjam</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="/pinjam/update/<?php echo e($pinjam->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Kode</label>
                                <input type="text" class="form-control" name="kode" value="<?php echo e($pinjam->kode); ?>"
                                    required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Baris</label>
                                <input type="number" class="form-control" name="baris" value="<?php echo e($pinjam->baris); ?>"
                                    required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Kolom</label>
                                <input type="number" class="form-control" name="kolom" value="<?php echo e($pinjam->kolom); ?>"
                                    required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aldin\OneDrive\Desktop\uas\SKD\uas\resources\views/pinjam/request.blade.php ENDPATH**/ ?>
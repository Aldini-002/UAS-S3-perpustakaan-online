<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="col-6 mb-3">
                <img src="/img/<?php echo e($buku->cover); ?>" class="rounded" alt="..." style="width: 300px; height: 400px">
                <br>
                <a href="" class="mb-3" data-bs-toggle="modal" data-bs-target="#cover">
                    Update cover
                </a>

                <p>Kode buku : <span class="text-danger"><?php echo e($buku->kode); ?></span></p>
                <p>Stok : <span class="text-danger"><?php echo e($buku->stok); ?></span></p>
                <p>Kategori : <span class="text-danger"><?php echo e($buku->kategori->kategori); ?></span></p>
                <p>Rak : <span class="text-danger"><?php echo e($buku->rak->kode); ?></span> | Baris :
                    <span class="text-danger"><?php echo e($buku->rak->baris); ?> </span> | Kolom : <span
                        class="text-danger"><?php echo e($buku->rak->kolom); ?> </span>
                </p>
                <h3 class="card-title"><?php echo e($buku->judul); ?></h3>
                <h6>Sipnosis</h6>
                <p><?php echo nl2br($buku->sinopsis); ?></p>
                <?php if(Auth::user()->role == 'admin'): ?>
                    <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#detail">Edit</a>
                    <a href="/buku/delete/<?php echo e($buku->id); ?>" class="btn btn-primary"
                        onclick="return confirm('Hapsu buku!')">Delete</a>
                    <a href="#" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#pinjamAdmin">Pinjam</a>
                <?php else: ?>
                    <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#pinjamUser">Pinjam</a>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <!-- cover Modal -->
    <div class="modal fade" id="cover" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Update cover</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/buku/update/cover/<?php echo e($buku->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Cover</label>
                            <input type="file" class="form-control" name="cover" value="<?php echo e(old('cover')); ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- detail Modal -->
    <div class="modal fade" id="detail" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Update detail</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/buku/update/detail/<?php echo e($buku->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Judul</label>
                            <input type="text" class="form-control" name="judul" value="<?php echo e($buku->judul); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Kode</label>
                            <input type="text" class="form-control" name="kode" value="<?php echo e($buku->kode); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Penerbit</label>
                            <input type="text" class="form-control" name="penerbit" value="<?php echo e($buku->penerbit); ?>"
                                required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Sinopsis</label>
                            <textarea class="form-control" rows="5" name="sinopsis" required><?php echo $buku->sinopsis; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Kategori</label>
                            <select class="form-select" name="id_kategori" required>
                                <option value="<?php echo e($buku->id_kategori); ?>" selected>
                                    <?php echo e($buku->kategori->kategori); ?>

                                </option>
                                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->kategori); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Rak</label>
                            <select class="form-select" name="id_rak" required>
                                <option value="<?php echo e($buku->id_rak); ?>" selected>Kode : <?php echo e($buku->rak->kode); ?> | Baris :
                                    <?php echo e($buku->rak->baris); ?> | Kolom : <?php echo e($buku->rak->kolom); ?></option>
                                <?php $__currentLoopData = $raks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($rak->id); ?>">Kode : <?php echo e($rak->kode); ?> | Baris :
                                        <?php echo e($rak->baris); ?> | Kolom : <?php echo e($rak->kolom); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Stok</label>
                            <input type="number" class="form-control" name="stok" value="<?php echo e($buku->stok); ?>"
                                required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- detail Modal -->
    <div class="modal fade" id="pinjamAdmin" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Data pinjam</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/pinjam/admin/<?php echo e($buku->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">ID User</label>
                            <input type="number" class="form-control" name="id_user" value="<?php echo e(old('id_user')); ?>"
                                required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Batas pinjam</label>
                            <input type="date" class="form-control" name="batas_pinjam"
                                value="<?php echo e(old('batas_pinjam')); ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Pinjam</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- detail Modal -->
    <div class="modal fade" id="pinjamUser" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Request pinjam</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="/pinjam/user/<?php echo e($buku->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Batas pinjam</label>
                            <input type="date" class="form-control" name="batas_pinjam"
                                value="<?php echo e(old('batas_pinjam')); ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Request</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Document\uas\SKD\uas\resources\views/buku/bukuDetail.blade.php ENDPATH**/ ?>
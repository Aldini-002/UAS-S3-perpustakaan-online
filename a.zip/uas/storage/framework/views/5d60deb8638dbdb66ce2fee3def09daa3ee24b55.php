<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="rew justify-content-center">
            <div class="col-6">
                <div class="row">
                    <div class="col-12">
                        <h1>Daftar pinjam</h1>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama peminjam</th>
                                    <th scope="col">Kode buku</th>
                                    <th scope="col">Tanggal pinjam</th>
                                    <th scope="col">Batas pinjam</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pinjams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($no++); ?></th>
                                        <td><?php echo e($pinjam->user->name); ?></td>
                                        <td><?php echo e($pinjam->buku->kode); ?></td>
                                        <td><?php echo e($pinjam->tanggal_pinjam); ?></td>
                                        <td><?php echo e($pinjam->batas_pinjam); ?></td>
                                        <td><a href="/kembali/<?php echo e($pinjam->id); ?>">Selesai</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if(Auth::user()->role == 'user'): ?>
                        <div class="col-12">
                            <h1>Menunggu konfirmasi</h1>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Nama peminjam</th>
                                        <th scope="col">Kode buku</th>
                                        <th scope="col">Tanggal pinjam</th>
                                        <th scope="col">Batas pinjam</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($no++); ?></th>
                                            <td><?php echo e($pending->user->name); ?></td>
                                            <td><?php echo e($pending->buku->kode); ?></td>
                                            <td><?php echo e($pending->tanggal_pinjam); ?></td>
                                            <td><?php echo e($pending->batas_pinjam); ?></td>
                                            <td><?php echo e($pending->status); ?></td>
                                            <td><a href="/pinjam/request/tolak/<?php echo e($pending->id); ?>">Batal</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aldin\OneDrive\Desktop\uas\SKD\uas\resources\views/pinjam/pinjam.blade.php ENDPATH**/ ?>